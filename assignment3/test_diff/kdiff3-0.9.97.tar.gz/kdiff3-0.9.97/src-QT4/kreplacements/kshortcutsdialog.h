#include "kreplacements.h"      
 

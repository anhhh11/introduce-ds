#ifndef STABLE_H
#define STABLE_H
#include <QtCore>
#include <QtGui>
#ifdef _WIN32
#include <qt_windows.h>
#endif
#endif

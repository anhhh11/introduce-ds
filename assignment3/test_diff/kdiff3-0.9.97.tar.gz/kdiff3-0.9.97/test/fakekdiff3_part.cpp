extern "C"
{
    void* init_libkdiff3part()
    {
        return 0;
    }
}
